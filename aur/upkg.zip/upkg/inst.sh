echo making program startable
chmod +x upkg
echo done you can start it via ./upkg
