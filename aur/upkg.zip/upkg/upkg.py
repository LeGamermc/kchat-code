import os
import getpass
hostname = "pakage.legamer4.repl.co"
ver = "0.3"
print("upkg ver " + ver + "\nthe package manager upkg is in beta so if they are bug tell us at:LeGamer55554@gmail.com \nplease be sure to have installed unzip and pip3 before installing any program from upkg\n")
while(1):
  inst = input("upkg$")
  if inst == ("exit"):
    break;
  elif inst == ("ver"):
    print("ver " + ver)
  elif inst == ("help"):
    print("list: listt all avalible program in upkg\nexit: exit the program\nver: tell the version\nupdate: update the upkg\n\ntype the name only to install the program")
  elif inst == ("list"):
    print("fetching the leatest version of the list of program...")
    os.system("wget https://pakage.legamer4.repl.co/list.txt")
    os.system("clear")
    os.system("cat list.txt")
    os.system("rm list.txt")
  elif inst == ("update"):
    print("fetching the leatest version of upkg...")
    os.system("wget https://pakage.legamer4.repl.co/ver.txt")
    file = open("ver.txt")
    os.system("clear")
    read  = file.read()
    if read > ver:
      print("Updating upkg...")
      os.chdir("..")
      os.system("wget https://pakage.legamer4.repl.co/aur/upkg.zip")
      print("updating upkg...25%")
      os.system("unzip upkg.zip")
      os.system("rm upkg.zip")
      print("updating upkg...50%")
      os.chdir("upkg")
      print("updating upkg...75%")
      os.system("bash inst.sh")
      print("updating upkg...100%\nupdating upkg...DONE")
      os.system("rm ver.txt")
      os.system("rm ver.txt.*")
      os.system("clear")
      os.system("./upkg")
    if read == ver:
      os.system("rm ver.txt")
      os.system("rm ver.txt.*")
      os.system("clear")
      print("you have allready the leastest version of upkg")
      while(1):
        break;
  else:
   print("the folowing package will be install " + inst)
   while(1):
     choise = input("y/n>")
     if choise == ("y"):
       print("Connectivity test server...")
       user = getpass.getuser()
       os.chdir("/home/" + user)
       response = os.system("ping -c 1 " + hostname)
       if response == 0:
           pingstatus = "Network Active"
           print("Connectivity test server...ONLINE")
       else:
           pingstatus = "Network Error"
           print("Connectivity test server...OFFLINE \ninstalation aborted")
           break; 
       print("fetching the porgram... [1/4]")
       os.system(f"sudo wget https://" + hostname + "/aur/" + inst + ".zip")
       print("unziping the program... [2/4]")
       os.system("unzip -o " + inst + ".zip")
       print("enter program directory... [3/4]")
       os.chdir(inst)
       print("configurating the program... [4/4]")
       os.system("sudo bash inst.sh") 
       os.chdir("..")
       os.system("sudo rm " + inst + ".zip")
       print("instalation done \n the porgram has been installed in the direcotry:/home/" + user + "/" + inst)
       break;
     if choise == ("n"):
       print("instalation aborted")
       break;
