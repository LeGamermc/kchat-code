echo please make sure you have installed tk whitout pip
echo making program executable...
chmod +x knote
echo making program executable...OK
echo you can now start the program via ./knote

