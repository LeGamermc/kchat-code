chmod +x devprog
