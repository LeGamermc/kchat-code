import tkinter as tk
import urllib.request
import io
from PIL import ImageTk, Image
import vlc
import json
import tempfile
import threading

# Define the server URL and the path to the videos JSON file
SERVER_URL = "https://ktube.legamer4.repl.co"
VIDEOS_JSON_URL = SERVER_URL + "/videos.json"

# Create the main window
root = tk.Tk()
root.title("Ktube open beta")

# Set the size of the window
root.geometry("800x600")

# Create a label for the window
label = tk.Label(root, text="Welcome to Ktube Platform where you can have mp3 and mp4!")
label.pack()
def create_video_widgets(video_id, video_path, video_frame2):
    video_frame = tk.Frame(video_frame2)

    # Create a label for the video title
    video_title = tk.Label(video_frame, text=video_id, font=("Arial", 14))
    video_title.pack(side="top", pady=10)

    # Create a button to play the video
    play_button = tk.Button(video_frame, text="Play Video", command=lambda vid=video_path, vf=video_frame: play_video(vid, vf))
    play_button.pack()

    # Add the video frame to the parent frame
    video_frame.pack(side="top")

    # Update the scroll region to show the new video
    canvas.config(scrollregion=canvas.bbox('all'))


def update_video_list():
    # Delete all widgets inside video_frame2
    for widget in video_frame2.winfo_children():
        widget.destroy()

    videos = json.loads(urllib.request.urlopen(SERVER_URL + "/videos.json").read().decode())

    # Add each video to the frame
    for video_id, video_path in videos.items():
        create_video_widgets(video_id, video_path, video_frame2)

    # Update the scrollbar
    canvas.config(scrollregion=canvas.bbox('all'))


# Create a frame to hold the video player

# Create a canvas to hold the video list and scrollbar
canvas = tk.Canvas(root, width=350, height=800)
canvas.pack(side="left", expand=True)

refresh_button = tk.Button(root, text="Refresh", command=update_video_list)
refresh_button.pack()

video_frame2 = tk.Frame(canvas)

canvas.create_window((0, 0), window=video_frame2, anchor='nw')
# Add a scrollbar to the canvas
scrollbar = tk.Scrollbar(root, orient="vertical", command=canvas.yview)
scrollbar.pack(side="right", fill="y")

# Configure the canvas to work with the scrollbar
canvas.configure(yscrollcommand=scrollbar.set)
canvas.bind('<Configure>', lambda e: canvas.configure(scrollregion=canvas.bbox('all')))
# Create a frame within the canvas to hold widgets
inner_frame = tk.Frame(canvas)
canvas.create_window((0, 0), window=inner_frame, anchor='nw')

# Add widgets to the inner frame
update_video_list()

# Create a frame to hold the video controls
controls_frame = tk.Frame(root)
controls_frame.pack()

# Create a canvas for the video list with a scrollbar


# Create a VLC media player instance
instance = vlc.Instance("--no-xlib")
player = instance.media_player_new()

# Create a frame to hold the video controls
controls_frame = tk.Frame(root)
controls_frame.pack()
    
# Create a volume button
def set_volume(val):
    player.audio_set_volume(int(val))

# Create a pause button
def pause_video():
    player.pause()


# Create a button to go back to the video list
def back_to_list():
    # Stop the video playback
    player.stop()

    # Show the video list and hide the video player
    video_frame.pack_forget()
    back_button.pack_forget()
    pause_button.pack_forget()
    volume_scale.pack_forget()
    update_video_list()

# Connect to the server and get the video data from the JSON file
videos_data = urllib.request.urlopen(VIDEOS_JSON_URL).read()
videos = json.loads(videos_data)

# Create a dictionary to store the media objects of each video
media_objects = {}

video_frame = tk.Frame(root)
video_frame.pack(side="bottom", fill="both")

# Create a frame to hold the video player and controls
# Create a "Back" button
back_button = tk.Button(video_frame, text="Stop", command=back_to_list)

# Create a "Play/Pause" button
pause_button = tk.Button(video_frame, text="Play/Pause", command=pause_video)

# Create a volume scale
volume_scale = tk.Scale(video_frame, from_=0, to=100, orient=tk.HORIZONTAL, command=set_volume)
volume_scale.set(50)

def play_video(video_path, video_frame):
    # Create a loading popup
    loading_popup = tk.Toplevel()
    loading_popup.geometry("200x100")
    loading_label = tk.Label(loading_popup, text="Loading, please wait...")
    loading_label.pack(expand=True)

    # Start a new thread to download and play the video
    threading.Thread(target=play_video_threaded, args=(video_path, video_frame, loading_popup)).start()

def play_video_threaded(video_path, video_frame, loading_popup):
    # Connect to the server and get the video data
    video_data = urllib.request.urlopen(SERVER_URL + video_path).read()

    # Create a temporary file to store the video data
    with tempfile.NamedTemporaryFile(delete=False) as f:
        f.write(video_data)
        temp_file_path = f.name

    # Create a new media object from the temporary file and play it
    media = instance.media_new(temp_file_path)
    player.set_media(media)

    # Create a video widget for the player
    # Get the player's HWND and use it to embed the video inside the Tkinter window
    player_hwnd = player.get_hwnd()
    if player_hwnd:
        player.set_xwindow(video_frame.winfo_id())

    # Start the video playback and attach an event listener to handle when the video ends
    player.play()
    player.event_manager().event_attach(vlc.EventType.MediaPlayerEndReached, end_video)
    back_button.pack(side="left")
    pause_button.pack(side=tk.LEFT)
    volume_scale.pack(side=tk.LEFT)
    video_frame.pack(side="bottom")
    loading_popup.destroy()

    # Close the loading popup

update_video_list()
def end_video(event):
    # Stop the video playback
    player.stop()

    # Show the video list and hide the video player and controls
    video_frame.pack_forget()
    control_frame.pack_forget()
    video_frame2.pack()


instance = vlc.Instance("--no-xlib")
player = instance.media_player_new()

# Create a frame to hold the video player and controls
video_frame = tk.Frame(root)
# Create a frame to hold the video list

control_frame = tk.Frame(root)

# Create a button to go back to the video list

# Create a slider to adjust the volume
volume_slider = tk.Scale(control_frame, from_=0, to=100, orient=tk.HORIZONTAL)
volume_slider.pack(side="right")

# Start the main loop to display the window
root.mainloop()
