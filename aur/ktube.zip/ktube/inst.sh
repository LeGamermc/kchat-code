echo [*]:installing requirement [1/1]...
pip install python-vlc
echo done, make sure to have vlc installed
echo [*]:making program executable...
chmod +x ktube
echo done (warning this program isin open beta many bug can occure)


