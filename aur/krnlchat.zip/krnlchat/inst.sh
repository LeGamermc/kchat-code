echo please make sure tk and pip3 is installed
pip3 install tk
chmod +x krnlchat
echo you can now start fetch with ./krnlchat
