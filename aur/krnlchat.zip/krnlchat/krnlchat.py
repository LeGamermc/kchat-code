
print("-=krnlchat V1=-\n[*]:loading main module...")
print("[*]:loading main module...[1/8]")
from socket import AF_INET, socket, SOCK_STREAM
print("[*]:loading main module...[2/8]")
from threading import Thread
print("[*]:loading main module...[3/8]")
from tkinter import messagebox
print("[*]:loading main module...[4/8]")
from tkinter import *
print("[*]:loading main module...[5/8]")
from tkinter.ttk import *
print("[*]:loading main module...[6/8]")
import tkinter
print("[*]:loading main module...[7/8]")
import signal 
print("[*]:loading main module...[8/8]")
import time
print("[*]:loading main module...OK")
import urllib.request
import io
from PIL import ImageTk, Image
top = Tk()
"""
The below function gets the latest messages from the server and inserts it into the Listbox object.
If the window has somehow been closed abruptly, we remove the user.
"""
print("[*]:loading client function...[1/4]")
def receive():
    stop = False
    while True and not stop:
        try:
            msg = clientSocket.recv(BUFFSIZE)
            if not msg:
                break
            decoded_msg = msg.decode('utf-8')
            msgList.insert(tkinter.END, decoded_msg)
            msgList.see(tkinter.END)
        except OSError:
            cleanAndClose()
            break

"""
The below function sends the messages of the user to the server to be broadcast, 
if the exit sequence is entered, user's data is purged, and the window is closed.
"""

def send_message(msg):
    """
    Sends a message to the server.

    :param msg: The message to be sent.
    """
    clientSocket.send(msg.encode('utf-8'))
    if msg == "{quit}":
        clientSocket.close()
        top.quit()

print("[*]:loading client function...[2/4]")
def send(event=None):
    msg = myMsg.get()
    myMsg.set("")
    send_message(msg)


"""
If the exit sequence is entered, this function is executed.
"""
print("[*]:loading client function...[3/4]")
def cleanAndClose(event=None):
    top.destroy()
    myMsg.set("{quit}")
    send()
    stop = True
print("[*]:loading client function...[4/4]")
def signal_handler(signal, frame):
    top.destroy()
    myMsg.set("{quit}")
    send()
    stop = True

def handle_connection():
    global clientSocket
    HOST = "5.tcp.eu.ngrok.io"
    PORT = 15604
    ADDR = (HOST, PORT)
    try:
        clientSocket = socket(AF_INET, SOCK_STREAM)
        clientSocket.connect(ADDR)
        receiveThread = Thread(target=receive)
        receiveThread.start()
    except ConnectionRefusedError:
        messagebox.showerror("Server Unreachable", "The server is unreachable. Please try again later.")
        cleanAndClose()
    except:
        messagebox.showerror("Error", "An error occurred while connecting to the server.")
        cleanAndClose()


signal.signal(signal.SIGINT, signal_handler)
print("[*]:loading client function...OK")
print("[*]:connecting to the server...")

url = "https://pakage.legamer4.repl.co/newpp.png"
with urllib.request.urlopen(url) as u:
    raw_data = u.read()

# create a PIL Image object from the raw data
image = Image.open(io.BytesIO(raw_data))

# create a PhotoImage object from the PIL Image
photo = ImageTk.PhotoImage(image)

if __name__ == '__main__':

    top.title('krnlchat Beta V1.3')
    # Load the image from URL

    # Use the PhotoImage object in a Label widget
    label = Label(top, image=photo)
    label.pack()


    messageFrame = tkinter.Frame(top)
    scrollbar = tkinter.Scrollbar(messageFrame)
    msgList = tkinter.Listbox(messageFrame, width = 50, yscrollcommand = scrollbar.set)
    scrollbar.pack(side=tkinter.RIGHT, fill=tkinter.Y)
    msgList.pack(expand=True, fill=tkinter.BOTH)
    msgList.pack(fill = tkinter.BOTH)
    messageFrame.pack(expand=True, fill=BOTH)

    myMsg = tkinter.StringVar()
    myMsg.set("")
    entryField = tkinter.Entry(top,textvariable = myMsg)
    entryField.bind("<Return>", send)
    entryField.pack(fill=X)
    sendButton = tkinter.Button(top, text = 'Send', command = send, height = 1, width = 7)
    sendButton.pack()
    top.protocol("WM_DELETE_WINDOW", cleanAndClose)

    BUFFSIZE = 1024
    handle_connection()
    print("[*]:connecting to the server...OK\n[*]:showing client gui...")

    receiveThread = Thread(target=receive)
    receiveThread.start()
    photo2 = PhotoImage(file = "beta1.png")
    top.iconphoto(False, photo2)
    tkinter.mainloop()  
    print("[*]:exiting...")
    receiveThread.join()


