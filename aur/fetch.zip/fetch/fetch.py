import os
import platform
import multiprocessing
import psutil
import shutil
def formatSize(bytes):
    try:
        bytes = float(bytes)
        kb = bytes / 1024
    except:
        return "Error"
    if kb >= 1024:
        M = kb / 1024
        if M >= 1024:
            G = M / 1024
            return "%.2fG" % (G)
        else:
            return "%.2fM" % (M)
    else:
        return "%.2fkb" % (kb)
total_memory, used_memory, free_memory = map(
    int, os.popen('free -t -m').readlines()[-1].split()[1:])
usage = shutil.disk_usage("/")
free_space = formatSize(usage[2])
core: str = multiprocessing.cpu_count()
ram: str = psutil.virtual_memory()[2]
avram: str = psutil.virtual_memory()[1]
osn: str = os.name
osk: str = platform.system()
oskv: str = platform.release()
print(f" CPU: NaN% \n CPU Core: {core} \n ram usage: {ram}% \n ram free: {avram} Byte \n free space: {free_space} \n os name: {osn} \n os kernel: {osk} \n kernel version: {oskv} \n -=fetch version beta=-")
