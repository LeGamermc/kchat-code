echo please make sure python and pip are installed
echo installing requirement...
pip3 install psutil
pip3 install pytest-shutil
echo done
chmod +x fetch
echo you can now start fetch with ./fetch
