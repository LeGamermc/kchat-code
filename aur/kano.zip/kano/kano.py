import os

def main():
    print("Welcome to kano")
    print("Enter the name of the file you want to edit")
    filename = input(">")
    while(1):
        os.system("clear")
        os.system("cls")
        print("-=main menu=-\n1:view the file (only work if the file exist)\n2:edit the file\n3:exit")
        prechoice = input(">")
        if prechoice == "1":
            os.system("clear")
            os.system("cls")
            f = open(filename, "r")
            print(f.read())
            print("\npress enter to return to the main menu")
            choicee = input()
            if choicee == "":
                print("")
        if prechoice == "2":
            while(1):
              os.system("clear")
              os.system("cls")
              print("Enter the content of the file (single line only)")
              content = input()
              f = open(filename, "w")
              f.write(content)
              f.close()
              print("Do you want to read the file? (y/n)")
              choice = input()
              if choice == "y":
                  os.system("clear")
                  os.system("cls")
                  f = open(filename, "r")
                  print(f.read())
              else:
                  os.system("clear")
                  os.system("cls")
                  
              print("want you to edit again the file? (y/n)")
              choice2 = input()
  
              if choice2 == "y":
                print("")
              else:
                f.close()
                os.system("clear")
                os.system("cls")
                print("File saved and closed\npress enter to return to the main menu")
                choicee = input()
                if choicee == "":
                    print("")
                    break
        if prechoice == "3":
            exit()

main()
