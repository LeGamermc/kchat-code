echo please make sure mpv is installed
chmod +x krnlBBS
echo you can now start fetch with ./krnlBBS
