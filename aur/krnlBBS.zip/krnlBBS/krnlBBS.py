import os
import os.path
import time
os.system("wget https://updatepakager.legamer4.repl.co/ip2.txt --quiet")

file_path="ip2.txt"
os.system("clear")
while not os.path.exists(file_path):
    print("kernelBBS connector]----------------------------------------------------------\n\n\n\n\n\n\n                           [exited...] \n                            ___   \n\n\n\n\n\n------------------------------------------------------------------------------- ")    
    os.system("rm ip.txt > null")
    os.system("rm ip2.txt > null")
    os.system("rm aol.mp3 > null")
    os.system("rm aol2.mp3 > null")
    os.system("rm null")
    exit()

if os.path.isfile(file_path):
    os.system("clear")
else:
    os.system("clear")
    print("kernelBBS connector]----------------------------------------------------------\n\n\n\n\n\n\n                           [exited...] \n                            ___   \n\n\n\n\n\n------------------------------------------------------------------------------- ")
    os.system("rm ip.txt > null")
    os.system("rm ip2.txt > null")
    os.system("rm aol.mp3 > null")
    os.system("rm aol2.mp3 > null")
    os.system("rm null")
    exit()

os.system("clear")
print("[kernelBBS connector]----------------------------------------------------------\n\n\n\n\n\n\n                           [starting up....] \n                            ___   \n\n\n\n\n\n------------------------------------------------------------------------------- ")
hostname: str = open("ip2.txt","r").readline()
response = os.system("ping -c 1 " + hostname)
if response == 0:
    pingstatus = "Network Active"
    os.system("clear")
else:
    pingstatus = "Network Error"
    os.system("clear")
    print("kernelBBS connector]----------------------------------------------------------\n\n\n\n\n\n\n                           [exited...] \n                            ___   \n\n\n\n\n\n------------------------------------------------------------------------------- ")
    os.system("rm ip.txt > null")
    os.system("rm ip2.txt > null")
    os.system("rm aol.mp3 > null")
    os.system("rm aol2.mp3 > null")
    os.system("rm null")
    exit()

print("[kernelBBS connector]----------------------------------------------------------\n\n\n\n\n\n\n                           [checking conection...] \n                            ___ ___  \n\n\n\n\n\n------------------------------------------------------------------------------- ")
os.system("wget https://updatepakager.legamer4.repl.co/ip.txt --quiet")
os.system("wget https://updatepakager.legamer4.repl.co/aol.mp3 --quiet")
os.system("wget https://updatepakager.legamer4.repl.co/aol2.mp3 --quiet")
token: str = open("ip.txt","r").readline()
os.system("clear")
print("[kernelBBS connector]----------------------------------------------------------\n\n\n\n\n\n\n                           [connecting....]\n                            ___ ___ ___ \n\n\n\n\n\n------------------------------------------------------------------------------- ")
os.system("mpv aol.mp3 > null --quiet")
os.system(f"telnet {token}")
os.system("clear")
os.system("mpv aol2.mp3 > null --quiet")
print("[kernelBBS connector]----------------------------------------------------------\n\n\n\n\n\n\n                           [exited....]\n                            ___ ___ ___ \n\n\n\n\n\n------------------------------------------------------------------------------- ")
os.system("rm ip.txt > null")
os.system("rm ip2.txt > null")
os.system("rm aol.mp3 > null")
os.system("rm aol2.mp3 > null")
os.system("rm null")
 
