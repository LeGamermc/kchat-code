echo installing the requirement....[1/1]
pip install Pillow
echo installing the requirement....OK
echo making program executable...
chmod +x krnlpaint
echo making program executable...OK
echo you can now start the program via ./krnlpaint
