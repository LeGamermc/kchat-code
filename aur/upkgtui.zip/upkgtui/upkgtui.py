import os
import getpass
import time
user = getpass.getuser()
os.chdir("/home/" + user)
os.system("rm tui.py")
os.system("clear")
print("╭────────────────────╮ \n│testing internet....│\n╰────────────────────╯")
response = os.system("ping -c 5 google.com -q > log.txt")
if response == 0:
    pingstatus = "Network Active"
    os.system("clear")
    print("testing internet....ONLINE")
else:
    pingstatus = "Network Error"
    os.system("clear")
    print("testing internet....OFFLINE \nyou do not have an internet  conection please check your internet conection try again later")
    time.sleep(5)
    exit()
os.system("clear")
print("╭──────────────────────────────╮ \n│testing server conectivity....│\n╰──────────────────────────────╯")
user = getpass.getuser()
os.chdir("/home/" + user)
response = os.system("ping -c 5 pakage.legamer4.repl.co -q > log.txt")
if response == 0:
    pingstatus = "Network Active"
    os.system("clear")
    print("testing server conectivity....ONLINE")
    os.system("wget https://pakage.legamer4.repl.co/upkgtui/tui.py")
    os.system("python3 tui.py")
else:
    pingstatus = "Network Error"
    os.system("clear")
    print("testing server conectivity....OFFLINE \nthe server cannot be reatched please try again later")
    time.sleep(5)
    exit()
