echo installing requirement...[1/2]
pip install pyqt6
echo installing requirement...[2/2]
pip install PyQt6-WebEngine
echo installing requirement...DONE
chmod +x knet
echo you can now start fetch with ./knet
