import os
import urllib.request
import json
import tkinter as tk
from tkinter import messagebox
import ctypes
import getpass
import shutil
from PIL import ImageTk, Image
import customtkinter
import sys

os.chdir(os.path.dirname(os.path.abspath(__file__)))
print("logs started..")
class PackageInstaller(tk.Tk):
    def __init__(self, root, url):
        self.root = root
        self.url = url
        self.packages = []
        self.selected_package = None
        self.package_listbox = None
        self.build_gui()

    def build_gui(self):
        self.root.title("UpkgGui V1")

        # Package listbox
        scrollbar = tk.Scrollbar(self.root)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.package_listbox = tk.Listbox(self.root, yscrollcommand=scrollbar.set)
        self.package_listbox.pack(fill=tk.BOTH, expand=True)

        scrollbar.config(command=self.package_listbox.yview)

        self.package_listbox.bind("<<ListboxSelect>>", self.on_package_select)

        # Install button
        install_button = customtkinter.CTkButton(self.root, text="Install", command=self.install_package)
        install_button.pack(side=tk.RIGHT)

        # Refresh button
        refresh_button = customtkinter.CTkButton(self.root, text="Refresh", command=self.refresh_packages)
        refresh_button.pack(side=tk.LEFT, padx=5)

        # Load packages
        self.load_packages()
        photo2 = ImageTk.PhotoImage(file = "upkggui.png")
        root.iconphoto(False, photo2)

    def load_packages(self):
        try:
            # Load the package database from all repos in repo.txt
            new_packages = []
            with open('repo.txt') as f:
                repos = f.read().splitlines()
            for repo in repos:
                if '#' in repo:
                    continue
                response = urllib.request.urlopen(f"{repo}/aur.json")
                data = json.loads(response.read().decode())
                new_packages += data['packages']

            # Remove any packages that are no longer in the repo
            current_packages = [p['name'] for p in self.packages]
            new_package_names = [p['name'] for p in new_packages]
            packages_to_remove = set(current_packages) - set(new_package_names)
            for package_name in packages_to_remove:
                index = current_packages.index(package_name)
                self.packages.pop(index)
                self.package_listbox.delete(index)

            # Add new package names to the listbox
            for package in new_packages:
                if package['name'] not in current_packages:
                    self.packages.append(package)
                    self.package_listbox.insert(tk.END, package['name'])

        except Exception as e:
            messagebox.showerror("Load Packages", f"Failed to load packages: {e}")

    def refresh_packages(self):
        # Reload packages
        self.load_packages()

    def on_package_select(self, event):
        index = self.package_listbox.curselection()
        if index:
            self.selected_package = self.packages[index[0]]

    def install_package(self):
        if self.selected_package is not None:
            package_url = f"{self.selected_package['location']}/{self.selected_package['file']}"
            print("Downloading package from:", package_url)
            try:
                # Download the package
                response = urllib.request.urlopen(package_url)
                data = response.read()
                temp_file = os.path.join(os.getcwd(), self.selected_package['file'])
                with open(temp_file, 'wb') as f:
                    f.write(data)

                # Extract the package
                print(f"Extracting package to {os.path.join(os.getcwd(), self.selected_package['name'])}...")
                shutil.unpack_archive(temp_file, extract_dir=os.path.join(os.getcwd(), self.selected_package['name']))

                # Clean up the temporary file
                os.remove(temp_file)

                # Run the setup program
                os.chdir(os.path.join(os.getcwd(), self.selected_package['name']))
                os.chdir(os.path.join(os.getcwd(), self.selected_package['name']))
                if os.name == "nt":
                    os.system("inst.bat")
                elif sys.platform.startswith("linux"):
                    os.system("bash inst.sh")
                os.chdir("..")
                os.chdir("..")
                print("program installed go see your upkggui folder")
            except Exception as e:
                messagebox.showerror("Install Package", f"Failed to install package: {e}")



if __name__ == "__main__":
    # Read the URLs from the file
    urls = []
    with open("repo.txt", "r") as f:
        for line in f:
            urls.append(line.strip())

    # Create a PackageInstaller instance for each URL
    root = tk.Tk()
    app = PackageInstaller(root, urls)
    root.mainloop()
