echo please make sure to have screen installed beacause launcher is unstopable to keep your server on 24/7 
pip install signals

