import json
import os
import sys
import time
from signal import signal, SIGPIPE, SIG_DFL 
from socket import AF_INET, SOCK_STREAM, socket
from threading import Thread

# Ignore SIG_PIPE and don't throw exceptions on it
signal(SIGPIPE, SIG_DFL)

# Constants
HOST = '127.0.0.1'
PORT = 5543
ADDR = (HOST, PORT)
BUFSIZ = 1024

# User database
USER_DATABASE_FILE = "users.json"
if os.path.exists(USER_DATABASE_FILE):
    with open(USER_DATABASE_FILE, "r") as f:
        users = json.load(f)
else:
    users = {"users": {}, "last_id": 0}

# Server variables
clients = {}
addresses = {}

# Server socket
server = socket(AF_INET, SOCK_STREAM)
server.bind(ADDR)

def save_users():
    with open(USER_DATABASE_FILE, "w") as f:
        json.dump(users, f, indent=4)

def generate_user_id():
    users["last_id"] += 1
    return users["last_id"]

def register_user(username, password):
    if username in users["users"]:
        return False, "Username already exists."
    else:
        user_id = generate_user_id()
        users["users"][username] = {"id": user_id, "password": password}
        save_users()
        return True, f"Registration successful. Your user id is {user_id}."

def authenticate_user(username, password):
    if username in users["users"] and users["users"][username]["password"] == password:
        return True, users["users"][username]["id"]
    else:
        return False, "Authentication failed. Invalid username or password."

def accept_incoming_connections():
    """Sets up handling for incoming clients."""
    while True:
        client, client_address = server.accept()
        print(f"{client_address[0]}:{client_address[1]} has connected.")
        client.send(bytes("Welcome to krnlchat V1.3, please log in or register using /login or /register.\n", "utf8"))
        print("info: client.net.join")
        addresses[client] = client_address
        Thread(target=handle_client, args=(client,)).start()

def get_user_list():
    """Returns a list of connected users"""
    return [clients[client] for client in clients]

def get_num_users():
    """Returns the number of connected users"""
    return len(clients)


def handle_client(client):
    """Handles a single client connection."""
    while True:
        try:
            msg = client.recv(BUFSIZ).decode("utf8")
            if not msg:
                break
            elif msg.startswith("/login"):
                _, username, password = msg.split()
                success, result = authenticate_user(username, password)
                if success:
                    client.send(bytes(f"Authentication successful. Your user id is {result} \n\n", "utf8"))
                    print("info: client.login.true")
                    clients[client] = result
                    break
                else:
                    client.send(bytes(result, "utf8"))
            elif msg.startswith("/register"):
                _, username, password, password_verify = msg.split()
                if password == password_verify:
                    success, result = register_user(username, password)
                    if success:
                        client.send(bytes(result, "utf8"))
                    else:
                        client.send(bytes(result, "utf8"))
                else:
                    client.send(bytes("Registration failed. Passwords do not match.\n", "utf8"))
                    print("info: guest.client.reg.fail")
            else:
                client.send(bytes("Please log in or register using /login or /register.\n", "utf8"))
        except ValueError:
            client.send(bytes("Invalid command.\n", "utf8"))
    name = username
    welcome = '\nWelcome %s! and have a great time in the chat' % name
    while True:
        if name == "{quit}":
            client.send(bytes("{quit}", "utf8"))
            client.close()
            del clients[client]
            num_users = get_num_users()
            broadcast(bytes(f"{name} has left the chat. ({num_users} users online)\n", "utf8"))
            print(f"info: {name}.client.exit")
            break
        else:
            client.send(bytes(welcome, "utf8"))
            msg = "%s has joined the chat!" % name
            print(f"info: {name}.client.join")
            clients[client] = name
            break

    while True:
        try:
            msg = client.recv(BUFSIZ)
        except ConnectionResetError:
            print("%s:%s connection reset." % addresses[client])
            client.close()
            broadcast(bytes(f"{name}:error=(network closed unexpectedly)" % name, "utf8"))
            print("err: net.user.reseted.client")
            del clients[client]
            break
        if msg != bytes("{quit}", "utf8"):
            if msg.decode().startswith("/list_users"):
                user_list = get_user_list()
                num_users = get_num_users()
                client.send(bytes(f"Users connected ({num_users}): {', '.join(user_list)}\n", "utf8"))
            elif msg.decode().startswith("/help"):
                client.send(bytes("help sytem:\n", "utf8"))
                client.send(bytes("\n /list_users: List all conected users\n", "utf8"))
            else:
                broadcast(msg, name + ": ")
        else:
            client.send(bytes("{quit}", "utf8"))
            client.close()
            del clients[client]
            num_users = get_num_users()
            broadcast(bytes(f"{name} has left the chat. ({num_users} users online)\n", "utf8"))
            print(f"info: {name}.client.exit")
            break


def broadcast(msg, prefix=""):  # prefix is for name identification.
    """Broadcasts a message to all the clients."""

    for sock in clients:
        sock.send(bytes(prefix, "utf8") + msg)

print(f"[*]:setting up IP and Port....OK\n[*]:this server operate with ip:{HOST} port:{PORT}")

if __name__ == "__main__":
    server.listen(5)
    print("[*]:Waiting for connection...")
    ACCEPT_THREAD = Thread(target=accept_incoming_connections)
    ACCEPT_THREAD.start()
    ACCEPT_THREAD.join()
    server.close()
