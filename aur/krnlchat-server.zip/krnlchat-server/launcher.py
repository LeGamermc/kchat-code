import os
while(1):
    os.system("pkill serv.py")
    os.system("clear")
    os.system("python3 serv.py")
    
