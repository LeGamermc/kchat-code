from tkinter import *
from tkinter import messagebox
import os

os.system("rm krnlchat.py")
os.system("rm krnlBBS.py")

class Window:
    def __init__(self, master):
        self.root = master
        title = Label(master, text= "Kernel HOME", background="cyan").pack()
 
        subframe = Frame(master)
        self.about_button = Button(text="krnlchat", width=10, command=self.krnlchat).pack(expand=True, fill=BOTH, side=LEFT)
 
        subframe2 = Frame(master)
        self.about_button = Button(text="krnlBBS", width=10, command=self.telnet).pack(expand=True, fill=BOTH, side=LEFT)
 
    def krnlchat(self):
        self.root.destroy()
        os.system("wget https://pakage.legamer4.repl.co/krnlHome/krnlchat.py")
        os.system("python3 krnlchat.py")
    def telnet(self):
        self.root.destroy()
        os.system("wget https://pakage.legamer4.repl.co/krnlHome/krnlBBS.py")
        messagebox.showinfo("info", "this app run on the terminal")
        os.system("python3 krnlBBS.py")

root = Tk()
root.geometry('300x200')
root.title("Kernel HOME")
window = Window(root)
root.mainloop()